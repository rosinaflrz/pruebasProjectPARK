import { makeRedirectUri } from 'expo-auth-session';

export const azureAuthConfig = {
    clientId: '39600664-31e0-44ad-8225-cc395c64871c',
    clientSecret: 'h5A8Q~dLjDK4KQtv.KSKFNaOHjzBSp8uJjo2rctV',
    redirectUri: makeRedirectUri({ useProxy: true }),
    scopes: ['openid', 'profile', 'email', 'offline_access', 'User.Read'],
    authorizationEndpoint: 'https://login.microsoftonline.com/6f0348f2-e498-45c9-84f4-c6d81dcffdfe/oauth2/v2.0/authorize',
    tokenEndpoint: 'https://login.microsoftonline.com/6f0348f2-e498-45c9-84f4-c6d81dcffdfe/oauth2/v2.0/token',
};