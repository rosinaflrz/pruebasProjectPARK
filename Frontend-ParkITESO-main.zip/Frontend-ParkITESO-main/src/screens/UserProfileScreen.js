import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, Button, StyleSheet, Alert } from 'react-native';
import { Dropdown } from 'react-native-element-dropdown';
import * as SecureStore from 'expo-secure-store';

const UserProfileScreen = ({ navigation }) => {
  const [userInfo, setUserInfo] = useState({
    displayName: '',
    mail: '',
    userType: '',
    staySchedules: '',
    preferredZone: '',
    preferredEntrance: '',
  });
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(false);

  useEffect(() => {
    const fetchUserInfo = async () => {
      try {
        const storedUserInfo = await SecureStore.getItemAsync('userInfo');
        if (storedUserInfo) {
          setUserInfo(JSON.parse(storedUserInfo));
        }
      } catch (error) {
        console.error('Error fetching user info:', error);
      }
      setLoading(false);
    };
    fetchUserInfo();
  }, []);

  const handleSave = async () => {
    const missingFields = [];

    if (!userInfo.displayName.trim()) missingFields.push('Nombre');
    if (!userInfo.staySchedules.trim()) missingFields.push('Horario de entrada');
    if (!userInfo.preferredZone.trim()) missingFields.push('Zona preferida');
    if (!userInfo.preferredEntrance.trim()) missingFields.push('Entrada preferida');

    if (missingFields.length > 0) {
      Alert.alert('Error', `Por favor complete los siguientes campos: ${missingFields.join(', ')}.`);
      return;
    }

    try {
      await SecureStore.setItemAsync('userInfo', JSON.stringify(userInfo));
      Alert.alert('Éxito', 'Perfil actualizado correctamente.');
      setEditing(false);
    } catch (error) {
      console.error('Error saving user info:', error);
      Alert.alert('Error', 'No se pudo actualizar el perfil.');
    }
  };

  const handleResetPreferences = () => {
    setUserInfo((prev) => ({
      ...prev,
      staySchedules: '',
      preferredZone: '',
      preferredEntrance: '',
    }));
  };

  if (loading) return <Text>Cargando...</Text>;

  return (
    <View style={styles.container}>
      <Text style={styles.label}>Email: {userInfo.mail}</Text>
      <Text style={styles.label}>Tipo de usuario: {userInfo.userType}</Text>

      <TextInput
        style={styles.input}
        value={userInfo.displayName}
        onChangeText={(text) => setUserInfo({ ...userInfo, displayName: text })}
        editable={editing}
        placeholder="Nombre"
        placeholderTextColor="gray"
      />

      <Text style={styles.label}>Horario de entrada</Text>
      <Dropdown
        style={styles.dropdown}
        placeholderStyle={styles.placeholderStyle}
        selectedTextStyle={styles.selectedTextStyle}
        inputSearchStyle={styles.inputSearchStyle}
        iconStyle={styles.iconStyle}
        data={[
          { label: '(7:00 - 9:00)', value: '7-9' },
          { label: '(9:00 - 11:00)', value: '9-11' },
          { label: '(11:00 - 13:00)', value: '11-13' },
          { label: '(13:00 - 15:00)', value: '13-15' },
          { label: '(15:00 - 16:00)', value: '15-16' },
          { label: '(16:00 - 18:00)', value: '16-18' },
          { label: '(18:00 - 20:00)', value: '18-20' },
          { label: '(20:00 - 22:00)', value: '20-22' }
        ]}
        maxHeight={300}
        labelField="label"
        valueField="value"
        placeholder="Selecciona un horario"
        value={userInfo.staySchedules}
        onChange={(item) => setUserInfo({ ...userInfo, staySchedules: item.value })}
        disabled={!editing}
      />

      <Text style={styles.label}>Zona preferida</Text>
      <Dropdown
        style={styles.dropdown}
        placeholderStyle={styles.placeholderStyle}
        selectedTextStyle={styles.selectedTextStyle}
        inputSearchStyle={styles.inputSearchStyle}
        iconStyle={styles.iconStyle}
        data={[
          { label: 'Zona A', value: 'A' },
          { label: 'Zona B', value: 'B' },
          { label: 'Zona C', value: 'C' },
        ]}
        maxHeight={300}
        labelField="label"
        valueField="value"
        placeholder="Selecciona una zona"
        value={userInfo.preferredZone}
        onChange={(item) => setUserInfo({ ...userInfo, preferredZone: item.value })}
        disabled={!editing}
      />

      <Text style={styles.label}>Entrada preferida</Text>
      <Dropdown
        style={styles.dropdown}
        placeholderStyle={styles.placeholderStyle}
        selectedTextStyle={styles.selectedTextStyle}
        inputSearchStyle={styles.inputSearchStyle}
        iconStyle={styles.iconStyle}
        data={[
          { label: 'Puerta 1', value: '1' },
          { label: 'Puerta 2', value: '2' },
          { label: 'Puerta 3', value: '3' },
          { label: 'Puerta 4', value: '4' },
        ]}
        maxHeight={300}
        labelField="label"
        valueField="value"
        placeholder="Selecciona una entrada"
        value={userInfo.preferredEntrance}
        onChange={(item) => setUserInfo({ ...userInfo, preferredEntrance: item.value })}
        disabled={!editing}
      />

      {editing ? (
        <>
          <Button title="Guardar" onPress={handleSave} />
          <Button title="Cancelar" onPress={() => setEditing(false)} color="red" />
        </>
      ) : (
        <Button title="Editar" onPress={() => setEditing(true)} />
      )}
      <Button title="Restablecer Preferencias" onPress={handleResetPreferences} color="orange" />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  label: {
    fontSize: 16,
    fontWeight: 'bold',
    marginTop: 10,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    padding: 10,
    marginVertical: 5,
    borderRadius: 5,
  },
  dropdown: {
    marginVertical: 5,
    height: 50,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    paddingHorizontal: 8,
  },
  placeholderStyle: {
    color: 'gray',
  },
  selectedTextStyle: {
    color: 'black',
  },
  inputSearchStyle: {
    height: 40,
    fontSize: 16,
  },
  iconStyle: {
    width: 20,
    height: 20,
  },
});

export default UserProfileScreen;