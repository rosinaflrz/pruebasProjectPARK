import React, { useEffect, useState } from 'react';
import { View, Button, Text, StyleSheet, Alert } from 'react-native';
import { useAuthRequest, makeRedirectUri } from 'expo-auth-session';
import axios from 'axios';
import * as SecureStore from 'expo-secure-store';
import { azureAuthConfig } from '../utils/auth';

const LoginScreen = ({ navigation }) => {
  const redirectUri = makeRedirectUri({ useProxy: true });
  const [userInfo, setUserInfo] = useState(null);

  const [request, response, promptAsync] = useAuthRequest(
    {
      clientId: azureAuthConfig.clientId,
      scopes: azureAuthConfig.scopes,
      redirectUri,
      responseType: 'code',
    },
    { authorizationEndpoint: azureAuthConfig.authorizationEndpoint }
  );

  useEffect(() => {
    if (response?.type === 'success' && response.params.code) {
      handleAuth(response.params.code);
    }
  }, [response]);

  const handleAuth = async (code) => {
    try {
      const tokenResponse = await axios.post(
        azureAuthConfig.tokenEndpoint,
        new URLSearchParams({
          client_id: azureAuthConfig.clientId,
          client_secret: azureAuthConfig.clientSecret,
          code,
          redirect_uri: redirectUri,
          grant_type: 'authorization_code',
        }),
        { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } }
      );

      const tokenData = tokenResponse.data;
      await SecureStore.setItemAsync('authToken', tokenData.access_token);

      const userResponse = await axios.get('https://graph.microsoft.com/v1.0/me', {
        headers: { Authorization: `Bearer ${tokenData.access_token}` },
      });
      
      const { mail, displayName, jobTitle } = userResponse.data;
      if (!mail.endsWith('@iteso.mx')) {
        Alert.alert('Acceso denegado', 'Solo se permiten cuentas @iteso.mx');
        await SecureStore.deleteItemAsync('authToken');
        return;
      }

      setUserInfo({ mail, displayName, jobTitle });
      await SecureStore.setItemAsync('userInfo', JSON.stringify({ mail, displayName, jobTitle }));
      navigation.replace('Home');
    } catch (error) {
      Alert.alert('Error de autenticación', error.response?.data?.error_description || 'Error desconocido');
    }
  };

  const handleLogout = async () => {
    await SecureStore.deleteItemAsync('authToken');
    await SecureStore.deleteItemAsync('userInfo');
    setUserInfo(null);
    navigation.replace('Login');
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Login</Text>
      {!userInfo ? (
        <Button title="Login with Microsoft" onPress={() => promptAsync()} disabled={!request} />
      ) : (
        <>
          <Text>Bienvenido, {userInfo.displayName}</Text>
          <Button title="Logout" onPress={handleLogout} />
        </>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontSize: 24,
    marginBottom: 20,
  },
});

export default LoginScreen;