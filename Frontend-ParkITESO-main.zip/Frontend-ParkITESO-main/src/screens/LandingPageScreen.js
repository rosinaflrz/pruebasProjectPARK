import React from 'react';
import { View, Text, Button, StyleSheet, Image } from 'react-native';
import { createDrawerNavigator } from '@react-navigation/drawer';
import Icon from 'react-native-vector-icons/Ionicons';

const ParkingMap = () => {
  return (
    <View style={styles.mapContainer}>
      <Image
        source={{ uri: 'https://example.com/parking-map.png' }} // Reemplaza con la URL de tu mapa
        style={styles.mapImage}
      />
      <Button title="Me estacion aquí" onPress={() => alert('¡Lugar de estacionamiento marcado!')} />
    </View>
  );
};

const HamburgerMenu = ({ navigation }) => {
  return (
    <View style={styles.menuContainer}>
      <Button title="Home" onPress={() => navigation.navigate('Home')} />
      <Button title="Profile" onPress={() => navigation.navigate('Profile')} />
      <Button title="Settings" onPress={() => navigation.navigate('Settings')} />
    </View>
  );
};

const Drawer = createDrawerNavigator();

const LandingPageScreen = () => {
  return (
    <Drawer.Navigator
      initialRouteName="Home"
      drawerContent={(props) => <HamburgerMenu {...props} />}
    >
      <Drawer.Screen name="Home" component={ParkingMap} />
    </Drawer.Navigator>
  );
};

const styles = StyleSheet.create({
  mapContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  mapImage: {
    width: '90%',
    height: 300,
    marginBottom: 20,
  },
  menuContainer: {
    flex: 1,
    paddingTop: 20,
  },
});

export default LandingPageScreen;